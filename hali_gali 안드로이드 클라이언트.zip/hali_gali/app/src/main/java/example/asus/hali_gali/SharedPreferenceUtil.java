package example.asus.hali_gali;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static android.content.Context.MODE_PRIVATE;

public class SharedPreferenceUtil {
    public static final String APP_SHARED_PREFS = "thisApp.SharedPreference";
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    Context mContext;

    public SharedPreferenceUtil(Context context) {
        this.sharedPreferences = context.getSharedPreferences(APP_SHARED_PREFS, MODE_PRIVATE);
        this.editor = sharedPreferences.edit();
        mContext=context;
    }

    public void setSharedTest(String test) {
        editor.putString("test", test);
        editor.commit();
    }

    public String getSharedTest() {
        return sharedPreferences.getString("test", "defValue"); // "test"는 키, "defValue"는 키에 대한 값이 없을 경우 리턴해줄 값 }
    }
}