package example.asus.hali_gali;

public class ListViewItem {
    private String roomNum;
    private String roomName;
    private String roomPerson;

    public void setRoomNum(String roomNum) {
        this.roomNum = roomNum;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public void setRoomPerson(String roomPerson) {
        this.roomPerson = roomPerson;
    }

    public String getRoomNum() {
        return roomNum;
    }

    public String getRoomName() {
        return roomName;
    }

    public String getRoomPerson() {
        return roomPerson;
    }
}
