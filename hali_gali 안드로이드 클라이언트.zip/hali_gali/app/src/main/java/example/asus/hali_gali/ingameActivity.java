package example.asus.hali_gali;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.SoundPool;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Vector;

public class ingameActivity extends AppCompatActivity {

    //  private String readyCode = "----";
    private String[] idCode = {null, "-", "-", "-", "-"};
    private Vector<Drawable> iconList;
    private String myId;
    private int myIdx = 0;
    int cur_Turn;
    String cur_Round;
    String roomNum;
    int myRemider_Card;
    int user1Remider_Card;
    int user2Remider_Card;
    int user3Remider_Card;
    int next_Turn;

    ImageButton bellBtn;
    Button readyBtn;
    Button chatBtn;
    FrameLayout chat_frag;
    RelativeLayout user1Layout;
    RelativeLayout myLayout;
    RelativeLayout user2Layout;
    RelativeLayout user3Layout;
    TextView myIdTxt;
    TextView user1Txt;
    TextView user2Txt;
    TextView user3Txt;
    TextView myReminder;
    TextView user1Reminder;
    TextView user2Reminder;
    TextView user3Reminder;
    TextView Round;
    ImageView myImage;
    ImageView user1Image;
    ImageView user2Image;
    ImageView user3Image;
    ImageView myTurn;
    ImageView user1Turn;
    ImageView user2Turn;
    ImageView user3Turn;

    chatFragment cf;
    FragmentTransaction tran;
    Intent chatIntent;
    boolean chat_flag = false;
    boolean chat_show = false;

    Context context;
    BroadcastReceiver mReceiver;
    MainActivity mainActivity;
    boolean ready = false;
    char default_char = 'N';

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingame);
        context = this;
        mainActivity = (MainActivity) MainActivity.mContext;
        Intent intent = getIntent();
        String rmTitle = intent.getStringExtra("roomTitle");
        mainActivity.sendMsg("10\t" + rmTitle);

        chat_frag = findViewById(R.id.chat_Frag);
        myLayout = findViewById(R.id.myLayout);
        user1Layout = findViewById(R.id.user1Layout);
        user2Layout = findViewById(R.id.user2Layout);
        user3Layout = findViewById(R.id.user3Layout);
        myIdTxt = findViewById(R.id.myIdTxt);
        Round=findViewById(R.id.roundView);
        user1Txt = findViewById(R.id.user1Txt);
        user2Txt = findViewById(R.id.user2Txt);
        user3Txt = findViewById(R.id.user3Txt);
        myReminder = findViewById(R.id.myRemainder);
        user1Reminder = findViewById(R.id.user1Remainder);
        user2Reminder = findViewById(R.id.user2Remainder);
        user3Reminder = findViewById(R.id.user3Remainder);
        myImage = findViewById(R.id.myImage);
        user1Image = findViewById(R.id.user1Image);
        user2Image = findViewById(R.id.user2Image);
        user3Image = findViewById(R.id.user3Image);
        chatBtn = findViewById(R.id.chatBtn);

        myTurn = findViewById(R.id.myTurn);
        user1Turn = findViewById(R.id.user1Turn);
        user2Turn = findViewById(R.id.user2Turn);
        user3Turn = findViewById(R.id.user3Turn);

        readyBtn = findViewById(R.id.readyBtn);
        bellBtn = findViewById(R.id.bellBtn);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("SEND_BROAD_CAST");
        mReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                int option = intent.getIntExtra("option", 99);
                Log.d("4449", "브로드캐스트 넘어온 값:" + option);
                switch (option) {
                    case 1:
                        if (chat_flag == true) {
                            String message = intent.getStringExtra("message");
                            String msgid = intent.getStringExtra("msgId");
                            chatIntent.putExtra("message", message);
                            chatIntent.putExtra("msgId", msgid);
                            sendBroadcast(chatIntent);
                        }
                        break;
                    case 11:
                        roomNum = intent.getStringExtra("roomNumber");
                        Log.d("5525", "" + roomNum);
                        mainActivity.sendMsg("16\t0\t");
                         //   break;
                    case 17:
                        int user1 = intent.getIntExtra("user1", 0);
                        char user1Num = intent.getCharExtra("user1Num", default_char);
                        setReadyUsers(user1, user1Num);
                        int user2 = intent.getIntExtra("user2", 0);
                        char user2Num = intent.getCharExtra("user2Num", default_char);
                        setReadyUsers(user2, user2Num);
                        int user3 = intent.getIntExtra("user3", 0);
                        char user3Num = intent.getCharExtra("user3Num", default_char);
                        setReadyUsers(user3, user3Num);
                        break;

                    case 18:
                        idCode = intent.getStringArrayExtra("IdCode");
                        myId = intent.getStringExtra("myID");
                        FindMyIndex();
                        SetPlayersId();
                        myIdTxt.setText(intent.getStringExtra("myID"));
                        user1Txt.setText(intent.getStringExtra("user1"));
                        user2Txt.setText(intent.getStringExtra("user2"));
                        user3Txt.setText(intent.getStringExtra("user3"));
                        break;

                    case 19:
                        bellBtn.setVisibility(View.VISIBLE);
                        readyBtn.setVisibility(View.GONE);
                        init_Image();
                        setReminderCard(myRemider_Card, user1Remider_Card, user2Remider_Card, user3Remider_Card);
                        break;

                    case 31:
                        cur_Turn = intent.getIntExtra("cur_Turn", 99); //99는 값이 안넘어온것
                        cur_Round = intent.getStringExtra("round");
                       // Round.setText(cur_Round+" 라운드");
                        setMyImageOnClick(cur_Turn);
                        if (cur_Turn == myIdx) {
                            myTurn.setVisibility(View.VISIBLE);
                        } else if (cur_Turn == 1)
                            user1Turn.setVisibility(View.VISIBLE);
                        else if (cur_Turn == 2)
                            user2Turn.setVisibility(View.VISIBLE);
                        else if (cur_Turn == 3)
                            user3Turn.setVisibility(View.VISIBLE);
                        break;

                    case 33:
                        remove_TurnSign();
                        int card_type = intent.getIntExtra("cardType", 99);
                        next_Turn = intent.getIntExtra("nextTurn", 99);
                        int reminder = intent.getIntExtra("reminder", 99);
                        setTurnSign(next_Turn);
                        setMyImageOnClick(next_Turn);
                        if (cur_Turn == myIdx) {
                            myRemider_Card = reminder;
                            card_animate(myImage, card_type);
                            myReminder.setText("남은 카드: " + reminder);
                            check_remindCard(myImage, reminder);
                        } else if (cur_Turn == 1) {
                            user1Remider_Card = reminder;
                            card_animate(user1Image, card_type);
                            user1Reminder.setText("남은 카드: " + reminder);
                            check_remindCard(user1Image, reminder);
                        } else if (cur_Turn == 2) {
                            user2Remider_Card = reminder;
                            card_animate(user2Image, card_type);
                            user2Reminder.setText("남은 카드: " + reminder);
                            check_remindCard(user2Image, reminder);
                        } else {
                            user3Remider_Card = reminder;
                            card_animate(user3Image, card_type);
                            user3Reminder.setText("남은 카드: " + reminder);
                            check_remindCard(user3Image, reminder);
                        }
                        cur_Turn = next_Turn;  //다음 차례로 넘어간다.
                        break;
                    case 35:
                        String[] msgArr = intent.getStringArrayExtra("reminder_Card");
                        setMyImageOnClick(cur_Turn);
                        if (intent.getStringExtra("fail_flag").equals("0")) {
                            Toast.makeText(getApplicationContext(), "떙!!", Toast.LENGTH_LONG).show();
                            setReminderCard(Integer.parseInt(msgArr[3]), Integer.parseInt(msgArr[4]), Integer.parseInt(msgArr[5]), Integer.parseInt(msgArr[6]));
                           Log.d("4449","nextturn="+next_Turn);

                        } else {
                            Toast.makeText(getApplicationContext(), cur_Round + "라운드 종료!!!", Toast.LENGTH_LONG).show();
                            remove_TurnSign();
                            setTurnSign(cur_Turn);
                            if (msgArr[2].equals("0"))
                                myReminder.setText("남은 카드:  " + msgArr[3]);
                            else if (msgArr[2].equals("1"))
                                user1Reminder.setText("남은 카드:  " + msgArr[3]);
                            else if (msgArr[2].equals("2"))
                                user2Reminder.setText("남은 카드:  " + msgArr[3]);
                            else
                                user3Reminder.setText("남은 카드:  " + msgArr[3]);
                        }
                        break;
                    case 36:
                        String msg = intent.getStringExtra("checkState");
                        reset_CardImage1(msg);
                        remove_TurnSign();
                        break;
                    case 37:
                        int winner=intent.getIntExtra("Winner",99);
                        String win;
                        if(winner==0)
                            win=myIdTxt.getText().toString();
                        else if(winner==1)
                            win=user1Txt.getText().toString();
                        else if(winner==2)
                            win=user2Txt.getText().toString();
                        else
                            win=user3Txt.getText().toString();
                        notify_Winner(win);
                        break;
                    case 38:
                      next_Turn=intent.getIntExtra("nextTurn",99);
                        remove_TurnSign();
                        setTurnSign(next_Turn);
                        cur_Turn=next_Turn;
                        break;
                }
            }
        };
        registerReceiver(mReceiver, intentFilter);
        cf = new chatFragment();
        InitIconList();
    }

    public void FindMyIndex() {
        for (int i = 0; i < 4; i++) {
            if (idCode[i + 1].equals(myId)) {
                this.myIdx = i;
                return;
            }
        }
    }

    public void card_animate(final ImageView im, final int pic) {   //카드 뒤집는 애니메이션
        final ObjectAnimator oa1 = ObjectAnimator.ofFloat(im, "scaleX", 1f, 0f);
        final ObjectAnimator oa2 = ObjectAnimator.ofFloat(im, "scaleX", 0f, 1f);
        oa1.setInterpolator(new DecelerateInterpolator());
        oa1.setDuration(250);
        oa2.setInterpolator(new AccelerateDecelerateInterpolator());
        oa2.setDuration(250);
        oa1.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                im.setImageDrawable(iconList.get(pic));
                oa2.start();
            }
        });
        oa1.start();
    }

    public void SetPlayersId() {
        int idx;
        for (int i = 0; i < 4; i++) {
            idx = (myIdx + i) % 4;
            if (idCode[idx + 1].equals("-")) {
                if (i == 1) {
                    user1Image.setImageResource(R.drawable.wait);
                    user1Txt.setText("");
                } else if (i == 2) {
                    user2Image.setImageResource(R.drawable.wait);
                    user2Txt.setText("");
                } else if (i == 3) {
                    user3Image.setImageResource(R.drawable.wait);
                    user3Txt.setText("");
                }
            }
        }
    }

    public void readyGame(View view) {
        if (ready == false) {
            readyBtn.setText("준비 취소");
            Log.d("103","준비취소");
            myImage.setImageResource(R.drawable.ready);
            mainActivity.sendMsg("16\t1\t");
            ready = true;
        } else {
            readyBtn.setText("준비");
            myImage.setImageResource(R.drawable.wait);
            Log.d("103","준비");
            mainActivity.sendMsg("16\t0\t");
            ready = false;
        }
    }

    public void setReadyUsers(int user, char userNum) {  //1은 유저1 ,2는 유저2, 3은 유저 3
        switch (user) {
            case 1:
                if (userNum == '1')
                    user1Image.setImageResource(R.drawable.ready);
                else if (userNum == '0')
                    user1Image.setImageResource(R.drawable.wait);
                else {
                    user1Image.setImageResource(R.drawable.wait);
                    user1Txt.setText(null);
                }
                break;
            case 2:
                if (userNum == '1')
                    user2Image.setImageResource(R.drawable.ready);
                else if (userNum == '0')
                    user2Image.setImageResource(R.drawable.wait);

                else {
                    user2Image.setImageResource(R.drawable.wait);
                    user2Txt.setText(null);
                }
                break;
            case 3:
                if (userNum == '1')
                    user3Image.setImageResource(R.drawable.ready);
                else if (userNum == '0')
                    user3Image.setImageResource(R.drawable.wait);
                else {
                    user3Image.setImageResource(R.drawable.wait);
                    user3Txt.setText(null);
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        unregisterReceiver(mReceiver);
        //mainActivity.sendMsg("15\t" + roomNum + "\t");

    }

    public void InitIconList() {
        iconList = new Vector<Drawable>();
        Drawable drawable;
        //0
        iconList.add(getResources().getDrawable(R.drawable.cardback));

        //1~5
        iconList.add(getResources().getDrawable(R.drawable.banana_1));
        iconList.add(getResources().getDrawable(R.drawable.banana_2));
        iconList.add(getResources().getDrawable(R.drawable.banana_3));
        iconList.add(getResources().getDrawable(R.drawable.banana_4));
        iconList.add(getResources().getDrawable(R.drawable.banana_5));

        //6~10
        iconList.add(getResources().getDrawable(R.drawable.lemon_1));
        iconList.add(getResources().getDrawable(R.drawable.lemon_2));
        iconList.add(getResources().getDrawable(R.drawable.lemon_3));
        iconList.add(getResources().getDrawable(R.drawable.lemon_4));
        iconList.add(getResources().getDrawable(R.drawable.lemon_5));

        //11~15
        iconList.add(getResources().getDrawable(R.drawable.peach_1));
        iconList.add(getResources().getDrawable(R.drawable.peach_2));
        iconList.add(getResources().getDrawable(R.drawable.peach_3));
        iconList.add(getResources().getDrawable(R.drawable.peach_4));
        iconList.add(getResources().getDrawable(R.drawable.peach_5));

        //16~20
        iconList.add(getResources().getDrawable(R.drawable.straw_1));
        iconList.add(getResources().getDrawable(R.drawable.straw_2));
        iconList.add(getResources().getDrawable(R.drawable.straw_3));
        iconList.add(getResources().getDrawable(R.drawable.straw_4));
        iconList.add(getResources().getDrawable(R.drawable.straw_5));

        /*//21~25
        iconList.add(new ImageIcon("Image/Board3.jpg"));
        iconList.add(new ImageIcon("Image/대기.png"));
        iconList.add(new ImageIcon("Image/준비.png"));*/
    }

    public void remove_TurnSign() {
        myTurn.setVisibility(View.GONE);
        user1Turn.setVisibility(View.GONE);
        user2Turn.setVisibility(View.GONE);
        user3Turn.setVisibility(View.GONE);
    }

    public void setReminderCard(int myRemider_Card, int user1Remider_Card, int user2Remider_Card, int user3Remider_Card) {
        myReminder.setText("남은 카드:  " + myRemider_Card);
        user1Reminder.setText("남은 카드:  " + user1Remider_Card);
        user2Reminder.setText("남은 카드:  " + user2Remider_Card);
        user3Reminder.setText("남은 카드:  " + user3Remider_Card);
    }

    public void setMyImageOnClick(int next_Turn) {
        if (myIdx == next_Turn) {
            myImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mainActivity.sendMsg("32\t" + myIdx + "\t");
                }
            });
        } else
            myImage.setOnClickListener(null);
    }

    public void init_Image() {   //시작시 카드 이미지 초기화
        reset_CardImage();
        myReminder.setVisibility(View.VISIBLE); //남은 카드 수 보여주기
        user1Reminder.setVisibility(View.VISIBLE);
        user2Reminder.setVisibility(View.VISIBLE);
        user3Reminder.setVisibility(View.VISIBLE);
        myRemider_Card = 14;
        user1Remider_Card = 14;
        user2Remider_Card = 14;
        user3Remider_Card = 14;
    }

    public void reset_CardImage() {
        myImage.setImageDrawable(iconList.get(0));
        user1Image.setImageDrawable(iconList.get(0));
        user2Image.setImageDrawable(iconList.get(0));
        user3Image.setImageDrawable(iconList.get(0));
    }

    public void reset_CardImage1(String msg) {
        String[] array = msg.split("");
        myImage.setImageDrawable(iconList.get(0));
        user1Image.setImageDrawable(iconList.get(0));
        user2Image.setImageDrawable(iconList.get(0));
        user3Image.setImageDrawable(iconList.get(0));
        Log.d("3268", "" + array[1] + "/" + array[2] + "/" + array[3] + "/" + array[4]);
        if (array[1].equals("0"))
            myImage.setImageDrawable(getResources().getDrawable(R.drawable.cemetry));
        if (array[2].equals("0"))
            user1Image.setImageDrawable(getResources().getDrawable(R.drawable.cemetry));
        if (array[3].equals("0"))
            user2Image.setImageDrawable(getResources().getDrawable(R.drawable.cemetry));
        if (array[4].equals("0"))
            user3Image.setImageDrawable(getResources().getDrawable(R.drawable.cemetry));
    }

    public void onChatstart(View view) {
        if (chat_flag == false) {
            chat_flag = true;
            chat_show = true;
            chatIntent = new Intent("send_Chat");
            Bundle bundle = new Bundle();
            bundle.putString("id", myId);
            cf.setArguments(bundle);
            tran = getFragmentManager().beginTransaction();
            tran.replace(R.id.chat_Frag, cf);
            tran.commit();
        } else if (chat_flag == true) {
            if (chat_show == true) {
                chat_frag.setVisibility(View.GONE);
                chat_show = false;
            } else {
                chat_frag.setVisibility(View.VISIBLE);
                chat_show = true;
            }
        }
    }

    public void onClickBell(View view) {
        mainActivity.sendMsg("34\t" + myIdx + "\t");
    }

    public void setTurnSign(int next_Turn) {
        if (next_Turn == 0)
            myTurn.setVisibility(View.VISIBLE);
        else if (next_Turn == 1)
            user1Turn.setVisibility(View.VISIBLE);
        else if (next_Turn == 2)
            user2Turn.setVisibility(View.VISIBLE);
        else
            user3Turn.setVisibility(View.VISIBLE);
    }

    public void check_remindCard(ImageView imageView, int flag) {
        if (flag == 0)
            imageView.setImageResource(R.drawable.cemetry);
    }

    public void notify_Winner(String str){
        // Alert을 이용해 종료시키기
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog  .setTitle("게임 종료")
                .setMessage("승자는 "+str+"!!!!")
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                }).create().show();
    }

}
