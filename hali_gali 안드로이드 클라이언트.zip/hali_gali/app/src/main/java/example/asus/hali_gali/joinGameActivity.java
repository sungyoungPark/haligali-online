
package example.asus.hali_gali;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.app.FragmentTransaction;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Vector;

public class joinGameActivity extends AppCompatActivity {

    Context context;
    BroadcastReceiver mReceiver;
    MainActivity mainActivity;
    boolean ready = false;
    char default_char = 'N';
    private Vector<Drawable> iconList;
    int myidIndex;
    String roomNum;
    private String[] idCode;
    private String myId;
    private int myIdx = 0;

    ImageButton j_bellBtn;
    Button j_readyBtn;
    FrameLayout chat_frag;
    RelativeLayout j_user0Layout;
    RelativeLayout j_user1Layout;
    RelativeLayout j_user2Layout;
    RelativeLayout j_user3Layout;
    TextView j_user1Txt;
    TextView j_user0Txt;
    TextView j_user2Txt;
    TextView j_user3Txt;
    TextView j_user0Reminder;
    TextView j_user1Reminder;
    TextView j_user2Reminder;
    TextView j_user3Reminder;
    ImageView j_user1Image;
    ImageView j_user0Image;
    ImageView j_user2Image;
    ImageView j_user3Image;
    ImageView user0Image;
    ImageView user1Image;
    ImageView user2Image;
    ImageView user3Image;
    ImageView user0Turn;
    ImageView user1Turn;
    ImageView user2Turn;
    ImageView user3Turn;

    int next_Turn;
    int j_user0Remider_Card;
    int j_user1Remider_Card;
    int j_user2Remider_Card;
    int j_user3Remider_Card;
    int roomNo;
    int cur_Turn;
    String cur_Round;

    chatFragment cf;
    FragmentTransaction tran;
    Intent chatIntent;
    boolean chat_flag = false;
    boolean chat_show = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_game);
        context = this;
        mainActivity = (MainActivity) MainActivity.mContext;

        Intent intent = getIntent();
        String rmTitle = intent.getStringExtra("roomTitle");
        roomNo = intent.getIntExtra("roomNo", 0);
        mainActivity.sendMsg("12\t" + roomNo + "\t");
        chat_frag=findViewById(R.id.j_chat_Frag);
        j_user1Layout = findViewById(R.id.j_user1Layout);
        j_user0Layout = findViewById(R.id.j_user0Layout);
        j_user2Layout = findViewById(R.id.j_user2Layout);
        j_user3Layout = findViewById(R.id.j_user3Layout);
        j_user1Txt = findViewById(R.id.j_user1Txt);
        j_user0Txt = findViewById(R.id.j_user0Txt);
        j_user2Txt = findViewById(R.id.j_user2Txt);
        j_user3Txt = findViewById(R.id.j_user3Txt);
        j_readyBtn = findViewById(R.id.j_readyBtn);
        j_bellBtn = findViewById(R.id.j_bellBtn);
        j_user1Image = findViewById(R.id.j_user1Image);
        j_user0Image = findViewById(R.id.j_user0Image);
        j_user2Image = findViewById(R.id.j_user2Image);
        j_user3Image = findViewById(R.id.j_user3Image);
        user0Turn = findViewById(R.id.j_user0Turn);
        user1Turn = findViewById(R.id.j_user1Turn);
        user2Turn = findViewById(R.id.j_user2Turn);
        user3Turn = findViewById(R.id.j_user3Turn);
        user0Image = findViewById(R.id.j_user0Image);
        user1Image = findViewById(R.id.j_user1Image);
        user2Image = findViewById(R.id.j_user2Image);
        user3Image = findViewById(R.id.j_user3Image);
         j_user0Reminder=findViewById(R.id.j_user0Remainder);
         j_user1Reminder=findViewById(R.id.j_user1Remainder);
         j_user2Reminder=findViewById(R.id.j_user2Remainder);
         j_user3Reminder=findViewById(R.id.j_user3Remainder);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("Join_SEND_BROAD_CAST");

        mReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                int option = intent.getIntExtra("option", 99);
                Log.d("4449", "브로드캐스트 넘어온 값:" + option);
                switch (option) {
                    case 1:
                        if (chat_flag == true) {
                            String message = intent.getStringExtra("message");
                            String msgid = intent.getStringExtra("msgId");
                            chatIntent.putExtra("message", message);
                            chatIntent.putExtra("msgId", msgid);
                            sendBroadcast(chatIntent);
                        }
                        break;
                    case 13:
                        roomNum = intent.getStringExtra("roomNumber");
                        Log.d("5525", "" + roomNum);
                        mainActivity.sendMsg("16\t0\t");
                        //break;
                    case 17:
                        int user0 = intent.getIntExtra("juser0", 0);
                        char user0Num = intent.getCharExtra("juser0Num", default_char);
                        setReadyUsers(user0, user0Num);
                        Log.d("852", "user0=" + user0Num);
                        int user1 = intent.getIntExtra("juser1", 0);
                        char user1Num = intent.getCharExtra("juser1Num", default_char);
                        setReadyUsers(user1, user1Num);
                        Log.d("852", "user1=" + user1Num);
                        int user2 = intent.getIntExtra("juser2", 0);
                        char user2Num = intent.getCharExtra("juser2Num", default_char);
                        setReadyUsers(user2, user2Num);
                        Log.d("852", "user2=" + user2Num);
                        int user3 = intent.getIntExtra("juser3", 0);
                        char user3Num = intent.getCharExtra("juser3Num", default_char);
                        setReadyUsers(user3, user3Num);
                        Log.d("852", "user3=" + user3Num);
                        break;

                    case 18:
                        idCode = intent.getStringArrayExtra("IdCode");
                        myidIndex = intent.getIntExtra("myIdIndex", 99)-1;
                        Log.d("741", "인덱스 들어온 값: " + myidIndex);
                        FindMyIndex();
                        SetPlayersId();
                        myId = idCode[myidIndex+1].trim();
                        Log.d("741", "아이디 들어온것 :" + myId);
                        j_user0Txt.setText(intent.getStringExtra("user0"));
                        j_user1Txt.setText(intent.getStringExtra("user1"));
                        j_user2Txt.setText(intent.getStringExtra("user2"));
                        j_user3Txt.setText(intent.getStringExtra("user3"));
                        break;

                    case 19:
                        j_bellBtn.setVisibility(View.VISIBLE);
                        j_readyBtn.setVisibility(View.GONE);
                        init_Image();
                        setReminderCard(j_user0Remider_Card, j_user1Remider_Card, j_user2Remider_Card, j_user3Remider_Card);
                        break;

                    case 31:
                        cur_Turn = intent.getIntExtra("cur_Turn", 99); //99는 값이 안넘어온것
                        cur_Round = intent.getStringExtra("round");
                        setMyImageOnClick(cur_Turn);
                        if (cur_Turn == 0) {
                            user0Turn.setVisibility(View.VISIBLE);
                        } else if (cur_Turn == 1)
                            user1Turn.setVisibility(View.VISIBLE);
                        else if (cur_Turn == 2)
                            user2Turn.setVisibility(View.VISIBLE);
                        else if (cur_Turn == 3)
                            user3Turn.setVisibility(View.VISIBLE);
                        break;

                    case 33:
                        remove_TurnSign();
                        int card_type = intent.getIntExtra("cardType", 99);
                        next_Turn = intent.getIntExtra("nextTurn", 99);
                        int reminder = intent.getIntExtra("reminder", 99);
                        setTurnSign(next_Turn);
                        setMyImageOnClick(next_Turn);

                        Log.d("9999","33 현재턴= "+cur_Turn);
                        if (cur_Turn == 0) {
                            j_user0Remider_Card = reminder;
                            card_animate(j_user0Image,card_type);
                            j_user0Reminder.setText("남은 카드: " + reminder);
                            check_remindCard(user0Image, reminder);
                        } else if (cur_Turn == 1) {
                            j_user1Remider_Card = reminder;
                            card_animate(j_user1Image,card_type);
                            j_user1Reminder.setText("남은 카드: " + reminder);
                            check_remindCard(user1Image, reminder);
                        } else if (cur_Turn == 2) {
                            j_user2Remider_Card = reminder;
                            card_animate(j_user2Image,card_type);
                            j_user2Reminder.setText("남은 카드: " + reminder);
                            check_remindCard(user2Image, reminder);
                        } else {
                            j_user3Remider_Card = reminder;
                            card_animate(j_user3Image,card_type);
                            j_user3Reminder.setText("남은 카드: " + reminder);
                            check_remindCard(user3Image, reminder);
                        }
                        cur_Turn = next_Turn;  //다음 차례로 넘어간다.
                        break;
                    case 35:
                        String[] msgArr = intent.getStringArrayExtra("reminder_Card");
                        setMyImageOnClick(cur_Turn);
                        if (intent.getStringExtra("fail_flag").equals("0")) {
                            Toast.makeText(getApplicationContext(), "떙!!", Toast.LENGTH_LONG).show();
                            setReminderCard(Integer.parseInt(msgArr[3]), Integer.parseInt(msgArr[4]), Integer.parseInt(msgArr[5]), Integer.parseInt(msgArr[6]));

                        } else {
                            Toast.makeText(getApplicationContext(), cur_Round + "라운드 승리!!", Toast.LENGTH_LONG).show();
                            remove_TurnSign();
                            setTurnSign(cur_Turn);
                            if (msgArr[2].equals("0"))
                                j_user0Reminder.setText("남은 카드:  " + msgArr[3]);
                            else if (msgArr[2].equals("1"))
                                j_user1Reminder.setText("남은 카드:  " + msgArr[3]);
                            else if (msgArr[2].equals("2"))
                                j_user2Reminder.setText("남은 카드:  " + msgArr[3]);
                            else
                                j_user3Reminder.setText("남은 카드:  " + msgArr[3]);
                        }
                        break;
                    case 36:
                        String msg=intent.getStringExtra("checkState");
                        reset_CardImage1(msg);
                        remove_TurnSign();
                        break;
                    case 37:
                        int winner=intent.getIntExtra("Winner",99);
                        String win;
                        if(winner==0)
                            win=j_user0Txt.getText().toString();
                        else if(winner==1)
                            win=j_user1Txt.getText().toString();
                        else if(winner==2)
                            win=j_user2Txt.getText().toString();
                        else
                            win=j_user3Txt.getText().toString();
                        notify_Winner(win);
                        break;
                    case 38:
                        next_Turn=intent.getIntExtra("nextTurn",99);
                        remove_TurnSign();
                        setTurnSign(next_Turn);
                        cur_Turn=next_Turn;
                        break;
                }
            }
        };
        registerReceiver(mReceiver, intentFilter);
        cf = new chatFragment();
        InitIconList();
    }

    public void FindMyIndex() {
        for (int i = 0; i < 4; i++) {
            if (idCode[i + 1].equals(myId)) {
                this.myIdx = i;
                return;
            }
        }
    }

    public void card_animate(final ImageView im, final int pic){   //카드 뒤집는 애니메이션
        final ObjectAnimator oa1=ObjectAnimator.ofFloat(im,"scaleX",1f,0f);
        final ObjectAnimator oa2=ObjectAnimator.ofFloat(im,"scaleX",0f,1f);
        oa1.setInterpolator(new DecelerateInterpolator());
        oa1.setDuration(250);
        oa2.setInterpolator(new AccelerateDecelerateInterpolator());
        oa2.setDuration(250);
        oa1.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                im.setImageDrawable(iconList.get(pic));
                //  im.setImageResource(pic);
                oa2.start();
            }
        });
        oa1.start();
    }


    public void SetPlayersId() {
        int idx;
        for (int i = 0; i < 4; i++) {
            idx = (myIdx + i) % 4;
            if (idCode[idx + 1].equals("-")) {
                if (i == 0) {
                    j_user0Image.setImageResource(R.drawable.wait);
                    j_user0Txt.setText("");
                }
                if (i == 1) {
                    j_user1Image.setImageResource(R.drawable.wait);
                    j_user1Txt.setText("");
                } else if (i == 2) {
                    j_user2Image.setImageResource(R.drawable.wait);
                    j_user2Txt.setText("");
                } else if (i == 3) {
                    j_user3Image.setImageResource(R.drawable.wait);
                    j_user3Txt.setText("");
                }
            }
        }
    }
    public void reset_CardImage() {
        user0Image.setImageDrawable(iconList.get(0));
        user1Image.setImageDrawable(iconList.get(0));
        user2Image.setImageDrawable(iconList.get(0));
        user3Image.setImageDrawable(iconList.get(0));
    }

    public void reset_CardImage1(String msg) {
        String[] array=msg.split("");
        user0Image.setImageDrawable(iconList.get(0));
        user1Image.setImageDrawable(iconList.get(0));
        user2Image.setImageDrawable(iconList.get(0));
        user3Image.setImageDrawable(iconList.get(0));
      if(array[1].equals("0"))
          user0Image.setImageDrawable(getResources().getDrawable(R.drawable.cemetry));
      if(array[2].equals("0"))
          user1Image.setImageDrawable(getResources().getDrawable(R.drawable.cemetry));
      if(array[3].equals("0"))
          user2Image.setImageDrawable(getResources().getDrawable(R.drawable.cemetry));
      if(array[4].equals("0"))
          user3Image.setImageDrawable(getResources().getDrawable(R.drawable.cemetry));
    }

    public void setReminderCard(int myRemider_Card, int user0Remider_Card, int user2Remider_Card, int user3Remider_Card) {
        j_user0Reminder.setText("남은 카드:  " + myRemider_Card);
        j_user1Reminder.setText("남은 카드:  " + user0Remider_Card);
        j_user2Reminder.setText("남은 카드:  " + user2Remider_Card);
        j_user3Reminder.setText("남은 카드:  " + user3Remider_Card);
    }

    public void readyGame(View view) {
        if (ready == false) {
            j_readyBtn.setText("준비 취소");
            //   j_user1Image.setImageResource(R.drawable.ready);
            mainActivity.sendMsg("16\t1\t");
            ready = true;
        } else {
            j_readyBtn.setText("준비");
            //  j_user1Image.setImageResource(R.drawable.wait);
            mainActivity.sendMsg("16\t0\t");
            ready = false;
        }
    }

    public void setReadyUsers(int user, char userNum) {  //1은 유저1 ,2는 유저2, 3은 유저 3
        switch (user) {
            case 0:
                if (userNum == '1')
                    j_user0Image.setImageResource(R.drawable.ready);
                else if (userNum == '0')
                    j_user0Image.setImageResource(R.drawable.wait);
                else {
                    j_user0Image.setImageResource(R.drawable.wait);
                    j_user0Txt.setText(null);
                }
                break;
            case 1:
                if (userNum == '1')
                    j_user1Image.setImageResource(R.drawable.ready);
                else if (userNum == '0')
                    j_user1Image.setImageResource(R.drawable.wait);
                else {
                    j_user1Image.setImageResource(R.drawable.wait);
                    j_user1Txt.setText(null);
                }
                break;
            case 2:
                if (userNum == '1')
                    j_user2Image.setImageResource(R.drawable.ready);
                else if (userNum == '0')
                    j_user2Image.setImageResource(R.drawable.wait);
                else {
                    j_user2Image.setImageResource(R.drawable.wait);
                    j_user2Txt.setText(null);
                }
                break;
            case 3:
                if (userNum == '1')
                    j_user3Image.setImageResource(R.drawable.ready);
                else if (userNum == '0')
                    j_user3Image.setImageResource(R.drawable.wait);
                else {
                    j_user3Image.setImageResource(R.drawable.wait);
                    j_user3Txt.setText(null);
                }
                break;
        }
    }

    public void InitIconList() {
        iconList = new Vector<Drawable>();
        Drawable drawable;
        //0
        iconList.add(getResources().getDrawable(R.drawable.cardback));

        //1~5
        iconList.add(getResources().getDrawable(R.drawable.banana_1));
        iconList.add(getResources().getDrawable(R.drawable.banana_2));
        iconList.add(getResources().getDrawable(R.drawable.banana_3));
        iconList.add(getResources().getDrawable(R.drawable.banana_4));
        iconList.add(getResources().getDrawable(R.drawable.banana_5));

        //6~10
        iconList.add(getResources().getDrawable(R.drawable.lemon_1));
        iconList.add(getResources().getDrawable(R.drawable.lemon_2));
        iconList.add(getResources().getDrawable(R.drawable.lemon_3));
        iconList.add(getResources().getDrawable(R.drawable.lemon_4));
        iconList.add(getResources().getDrawable(R.drawable.lemon_5));

        //11~15
        iconList.add(getResources().getDrawable(R.drawable.peach_1));
        iconList.add(getResources().getDrawable(R.drawable.peach_2));
        iconList.add(getResources().getDrawable(R.drawable.peach_3));
        iconList.add(getResources().getDrawable(R.drawable.peach_4));
        iconList.add(getResources().getDrawable(R.drawable.peach_5));

        //16~20
        iconList.add(getResources().getDrawable(R.drawable.straw_1));
        iconList.add(getResources().getDrawable(R.drawable.straw_2));
        iconList.add(getResources().getDrawable(R.drawable.straw_3));
        iconList.add(getResources().getDrawable(R.drawable.straw_4));
        iconList.add(getResources().getDrawable(R.drawable.straw_5));

/*/21~25
        iconList.add(new ImageIcon("Image/Board3.jpg"));
        iconList.add(new ImageIcon("Image/대기.png"));
        iconList.add(new ImageIcon("Image/준비.png"));*/

    }

    public void setTurnSign(int next_Turn) {
        if (next_Turn == 0)
            user0Turn.setVisibility(View.VISIBLE);
        else if (next_Turn == 1)
            user1Turn.setVisibility(View.VISIBLE);
        else if (next_Turn == 2)
            user2Turn.setVisibility(View.VISIBLE);
        else
            user3Turn.setVisibility(View.VISIBLE);
    }

    public void init_Image() {   //시작시 카드 이미지 초기화
        reset_CardImage();
        j_user0Reminder.setVisibility(View.VISIBLE); //남은 카드 수 보여주기
        j_user1Reminder.setVisibility(View.VISIBLE);
        j_user2Reminder.setVisibility(View.VISIBLE);
        j_user3Reminder.setVisibility(View.VISIBLE);
        j_user0Remider_Card = 14;
        j_user1Remider_Card = 14;
        j_user2Remider_Card = 14;
        j_user3Remider_Card = 14;
    }

    public void remove_TurnSign() {
        user0Turn.setVisibility(View.GONE);
        user1Turn.setVisibility(View.GONE);
        user2Turn.setVisibility(View.GONE);
        user3Turn.setVisibility(View.GONE);
    }

    public void check_remindCard(ImageView imageView, int flag) {
        if (flag == 0)
            imageView.setImageResource(R.drawable.cemetry);
    }

    public void onChatstart(View view) {
        if (chat_flag == false) {
            chat_flag = true;
            chat_show = true;
            chatIntent = new Intent("send_Chat");
            Bundle bundle = new Bundle();
            bundle.putString("id", myId);
            cf.setArguments(bundle);
            tran = getFragmentManager().beginTransaction();
            tran.replace(R.id.j_chat_Frag, cf);
            tran.commit();
        } else if (chat_flag == true) {
            if (chat_show == true) {
                chat_frag.setVisibility(View.GONE);
                chat_show = false;
            } else {
                chat_frag.setVisibility(View.VISIBLE);
                chat_show = true;
            }
        }
    }

    public void setMyImageOnClick(int next_Turn) {
        Log.d("333","next="+next_Turn+"/ my index="+myidIndex);
        if (myidIndex == next_Turn) {
            switch (myidIndex) {
                case 0:
                    user0Image.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mainActivity.sendMsg("32\t" + myidIndex + "\t");
                        }
                    });
                    break;
                case 1:
                    user1Image.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mainActivity.sendMsg("32\t" + myidIndex + "\t");
                        }
                    });
                break;
                case 2:
                    user2Image.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mainActivity.sendMsg("32\t" + myidIndex + "\t");
                        }
                    });
                case 3:
                    user3Image.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mainActivity.sendMsg("32\t" + myidIndex + "\t");
                        }
                    });
                    break;
            }
        } else {
            user0Image.setOnClickListener(null);
            user1Image.setOnClickListener(null);
            user2Image.setOnClickListener(null);
            user3Image.setOnClickListener(null);
        }
    }

    public void onClickBell(View view) {
        mainActivity.sendMsg("34\t" + myidIndex + "\t");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        unregisterReceiver(mReceiver);
        mainActivity.sendMsg("15\t" + roomNum + "\t");

    }

    public void notify_Winner(String str){
        // Alert을 이용해 종료시키기
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog  .setTitle("게임 종료")
                .setMessage("승자는 "+str+"!!!!")
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                }).create().show();
    }

}

