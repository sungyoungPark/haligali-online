package example.asus.hali_gali;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class chatFragment extends Fragment {

    View view;
    MainActivity mainActivity;
    TextView rcv_message;
    EditText sendTxt;
    Button sendBtn;
    String msg="";

    BroadcastReceiver chatRec;

    String myId;
    public chatFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_chat,container,false);
        mainActivity=(MainActivity)MainActivity.mContext;
       rcv_message=view.findViewById(R.id.msgTxt);
       sendTxt=view.findViewById(R.id.sendTxt);
       sendBtn=view.findViewById(R.id.sendBtn);

       Bundle bundle=this.getArguments();
       if(bundle!=null){
           myId=bundle.getString("id","NO Id");
       }
        Log.d("1234",""+myId);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("send_Chat");
       chatRec=new BroadcastReceiver() {
           @Override
           public void onReceive(Context context, Intent intent) {
               String str=intent.getStringExtra("message");
               String msgId=intent.getStringExtra("msgId");
               msg=msg+"["+msgId+"] : "+str+"\n";
               rcv_message.setText(msg);
           }
       };
        getActivity().registerReceiver(chatRec, intentFilter);

       sendBtn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               mainActivity.sendMsg("1\t"+myId+"\t"+sendTxt.getText().toString()+"\t");
               sendTxt.setText("");
           }
       });
        return  view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }
}
