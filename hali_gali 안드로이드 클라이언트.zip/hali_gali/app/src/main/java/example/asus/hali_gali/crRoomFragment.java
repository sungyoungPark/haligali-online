package example.asus.hali_gali;

import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link crRoomFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link crRoomFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class crRoomFragment extends Fragment {

    gameListActivity gameListActivity;
    Button create;
    EditText roomTitle;
    sendActivityListener sendActivityListener;
    MainActivity mainActivity;

    private OnFragmentInteractionListener mListener;

    public crRoomFragment() {
        // Required empty public constructor
    }

    public static crRoomFragment newInstance() {
        return new crRoomFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mainActivity=(MainActivity)MainActivity.mContext;
        final ViewGroup crRoom=(ViewGroup)inflater.inflate(R.layout.fragment_cr_room,container,false);
        create=crRoom.findViewById(R.id.create);
        roomTitle=crRoom.findViewById(R.id.roomTitle);

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               getActivity().getFragmentManager().beginTransaction().remove(crRoomFragment.this).commit();  //버튼 누르면 현재 띄어 놓은 프레그먼트 삭제
                Intent intent=new Intent(mainActivity,ingameActivity.class);
                intent.putExtra("roomTitle",roomTitle.getText().toString());
                startActivity(intent);
                getActivity().getFragmentManager().popBackStack();

            }
        });

        return crRoom;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof  sendActivityListener){
            sendActivityListener=(sendActivityListener)context;
        }else{
            throw new RuntimeException(context.toString()+"must implement sendActivityListener");
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        sendActivityListener=null;
    }

    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }

    public interface sendActivityListener{
        void sendActivitySet(String msg);
    }


}
