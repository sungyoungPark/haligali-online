package example.asus.hali_gali;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Set;

public class gameListActivity extends AppCompatActivity
        implements crRoomFragment.sendActivityListener
{
    MainActivity mainActivity;

    Button createRMBtn;
    Button exitBtn;
    Button refreshBtn;
    String mmsg;
    ArrayList<String> items;
   // ArrayAdapter adapter;
    ListView listView;
    ListViewAdapter adapter;
    SharedPreferenceUtil sharedPreference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_list);
        mainActivity=(MainActivity)MainActivity.mContext;
        sharedPreference=new SharedPreferenceUtil(getApplicationContext());
        createRMBtn=findViewById(R.id.createRMBtn);
        exitBtn=findViewById(R.id.exitBtn);
        refreshBtn=findViewById(R.id.refreshBtn);


        items=new ArrayList<String>();
        items=getArrayList("roomInfo");

        adapter=new ListViewAdapter();

        listView=(ListView)findViewById(R.id.roomList);
        listView.setAdapter(adapter);
        String roomCount=sharedPreference.getSharedTest();
        if(Integer.parseInt(roomCount)!=0) {
            for (int i = 0; i < items.size(); i++) {
                String[] roomInfo = items.get(i).split("<<");
                adapter.addItem(String.valueOf(i+1), roomInfo[0], roomInfo[1]);
            }
        }
        adapter.notifyDataSetChanged();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               String[] roomInfo=items.get(position).split("<<");
                Intent intent=new Intent(mainActivity,joinGameActivity.class);
                intent.putExtra("roomTitle",roomInfo[0].trim());
                intent.putExtra("roomNo",(position+1));
                startActivity(intent);
            }
        });

    }



   public void createRoom(View view){  //방 만드는 창 생성 ->프래그먼트 이용
       Fragment fg;
       fg=crRoomFragment.newInstance();
       setcrRoomFragment(fg);
    }

    public void refreshRoom(View view) {  //방 정보를 최신화 시켜줌
        items.clear();
        adapter.notifyDataSetChanged();
        mainActivity.sendMsg("14");

            adapter.notifyDataSetChanged();
            items = new ArrayList<String>();
            items = getArrayList("roomInfo");
            adapter = new ListViewAdapter();
            listView.setAdapter(adapter);
            String roomCount = sharedPreference.getSharedTest();
            if (Integer.parseInt(roomCount) != 0) {
                for (int i = 0; i < items.size(); i++) {
                    String[] roomInfo = items.get(i).split("<<");
                    adapter.addItem(String.valueOf(i + 1), roomInfo[0], roomInfo[1]);
                }
            }
            adapter.notifyDataSetChanged();
    }

    private void setcrRoomFragment(Fragment child){
        FragmentTransaction childFrag=getFragmentManager().beginTransaction();
        childFrag.replace(R.id.crRoom,child);
        childFrag.commit();
    }


    @Override
    public void sendActivitySet(String msg) { //프래그먼트에서 받은 방 정보를 메인 액티비티로 전달
        mmsg=msg;
        Toast.makeText(this,msg,Toast.LENGTH_LONG).show();
        items.add(msg);  //아이템 추가
        sendMainActivity(msg);

    }


    public void sendMainActivity(String msg){    //프래그먼트에서 받은 방 정보를 메인 액티비티로 전달
        Intent resultIntent=new Intent();
        resultIntent.putExtra("to_main",msg);
        setResult(RESULT_OK,resultIntent);
        finish();
    }

    public ArrayList<String> getArrayList(String key){   //쉐어드프리퍼런스에서 배열 갖고 오기
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        Gson gson = new Gson();
        String json = prefs.getString(key, null);
        Type type = new TypeToken<ArrayList<String>>() {}.getType();
        return gson.fromJson(json, type);
    }

    @Override
    protected void onDestroy() {
        items.clear();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        mainActivity.sendMsg("8\t");
    }
}
