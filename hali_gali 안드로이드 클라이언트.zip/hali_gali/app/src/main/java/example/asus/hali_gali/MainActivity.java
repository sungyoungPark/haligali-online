package example.asus.hali_gali;

import android.app.FragmentTransaction;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;

public class MainActivity extends AppCompatActivity {

    public static Context mContext;
    Button loginBtn;
    EditText ipText;
    EditText idText;
    EditText pwdText;

    final String ip = "10.0.2.2";
    //final String ip="192.168.0.8";
    //final String ip = "192.168.123.101";
    Socket socket;

    private InputStream is;
    private OutputStream os;
    private DataInputStream dis;
    private DataOutputStream dos;

    String id;
    String pwd;
    private boolean status;
    private Thread thread;
    SendThread send;
    String r_msg;

    SharedPreferenceUtil sharedPreference;
    ArrayList<String> myArrayList;

    Intent intent;
    Intent sendIntent;   //게임 생성할 때 브로드 캐스트 리시버
    Intent join_sendIntent;  //게임 입장할때 브로드 캐스트 리시버
    int Intent_falg = 0;  //0이면 게임 생성,1이면 게임 입장
    boolean inGame_flag = false; //게임 시작하면 true

    int curRoomNo;
    int myIdIndex;  //프로토콜 18에서 내 아이디가 저장되어 있는 주소값

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myArrayList = new ArrayList<String>();
        mContext = this;
        loginBtn = findViewById(R.id.loginBtn);
        ipText = findViewById(R.id.ipText);
        idText = findViewById(R.id.idText);
        pwdText = findViewById(R.id.pwdText);
        sendIntent = new Intent("SEND_BROAD_CAST");
        join_sendIntent = new Intent("Join_SEND_BROAD_CAST");
        sharedPreference = new SharedPreferenceUtil(getApplicationContext());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case 3000:
                    String msg;
                    msg = data.getStringExtra("to_main");
                    Toast.makeText(this, msg + "메인에서 받음", Toast.LENGTH_LONG).show();
                    String str = "10 " + "\t" + msg;
                    sendMsg(str);
                    break;
            }
        }
    }

    public void sendMsg(String msg) {
        send = new SendThread(socket, msg);
        send.start();
    }


    public void mLoginClick(View view) {
        id = idText.getText().toString();
        pwd = pwdText.getText().toString();
        if (id == null || pwd == null) {
            Toast.makeText(this, "아이디와 비밀번호를 모두 입력하시오.", Toast.LENGTH_LONG).show();
        } else {
            connectServer();
          /*  intent = new Intent(getApplicationContext(), gameListActivity.class);
            startActivityForResult(intent, 3000);*/
        }
    }

    class SendThread extends Thread {
        private Socket socket;
        String sendmsg;
        DataOutputStream output;

        public SendThread(Socket socket, String str) {
            sendmsg = str;
            this.socket = socket;
            try {
                output = new DataOutputStream(socket.getOutputStream());
            } catch (Exception e) {
            }
        }

        public void run() {
            try {
                if (output != null) {
                    if (sendmsg != null) {
                        //output.writeUTF(mac + "  :  " + sendmsg);
                        byte[] bb;
                        bb = sendmsg.getBytes("euc-kr");
                        output.write(bb); //.writeUTF(str);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (NullPointerException npe) {
                npe.printStackTrace();

            }
        }
    }


    public void connectServer() {
        new Thread() {
            public void run() {
                try {
                    socket = new Socket(ipText.getText().toString(), 33356);
                    Log.d("[Client]", " Server connected !!");
                    is = socket.getInputStream();
                    dis = new DataInputStream(is);
                    os = socket.getOutputStream();
                    dos = new DataOutputStream(os);
                    try {
                        //String str = ip; // loign ip 전송
                        String str=ipText.getText().toString();  //ip전송
                        String str1 = "6 " + "\t" + id + "\t" + pwd + "\t";
                        byte[] bb;
                        bb = str.getBytes("ksc5601");
                        dos.write(bb); //.writeUTF(str);
                        sendMsg(str1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    thread = new Thread(new ReceiveMsg());
                    thread.setDaemon(true);
                    thread.start();
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.d("[MultiChatClient]", " connectServer() Exception !!");
                }
            }
        }.start();

    }


    class ReceiveMsg implements Runnable {
        @SuppressWarnings("null")
        @Override
        public void run() {
            status = true;
            while (status) {
                try {
                    byte[] b = new byte[64];
                    dis.read(b);
                    String msg = new String(b, "euc-kr"); //+ "\n";
                    msg = msg.trim();
                    Log.d("789", msg);
                    ExecMsg(msg);

                } catch (IOException e) {
                    //e.printStackTrace();
                    //status = false;
                    try {
                        os.close();
                        is.close();
                        dos.close();
                        dis.close();
                        socket.close();
                        break;
                    } catch (IOException e1) {
                        e.printStackTrace();
                    }
                }
            }
            Log.d("[MultiChatClient]", " Stopped");
        }
    }


    public void ExecMsg(String msg) {
        String[] msgArr = msg.split("\t");
        String cmd = msgArr[0];
        Log.d("4449", cmd);

        if (cmd == null)
            return;
            //메세지 응답
        else if (cmd.equals("1")) {   //채팅 시작
            if (Intent_falg == 0) {
                sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim())); //옵션 값을 인게임 액티비티로 넘겨줌
                sendIntent.putExtra("msgId", msgArr[1]);
                sendIntent.putExtra("message", msgArr[2]);
                sendBroadcast(sendIntent);
            }
         else {
                join_sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim())); //옵션 값을 인게임 액티비티로 넘겨줌
                join_sendIntent.putExtra("msgId", msgArr[1]);
                join_sendIntent.putExtra("message", msgArr[2]);
                sendBroadcast(join_sendIntent);
            }

        }
        //로그인 응답
        else if (cmd.equals("7")) {
            //로그인 처리
            String str2 = "14\t";
            sendMsg(str2);
            if (msgArr[1].equals("0") ||msgArr[1].equals("1")) {
                this.id = msgArr[2].trim();
                intent = new Intent(getApplicationContext(), gameListActivity.class);
                startActivityForResult(intent, 3000);
            }
             else if (msgArr[1].equals("2")) {
            Toast.makeText(this,"비밀번호가 올바르지 않습니다.",Toast.LENGTH_SHORT).show();

            } else if (msgArr[1].equals("3")) {
            Toast.makeText(this,"이미 접속 중인 계정입니다..",Toast.LENGTH_SHORT).show();
            }
        }
        //로그아웃
        else if (cmd.equals("8")) {
            /* CM.ChangeView(0);*/
            this.id = null;
        }
        //방 생성 응답
        else if (cmd.equals("11")) {
            Intent_falg = 0;
            if (msgArr[1].equals("0")) {
                Log.d("5525", "메인에서 방번호:" + msgArr[2].trim());
                sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim())); //옵션 값을 인게임 액티비티로 넘겨줌
                sendIntent.putExtra("roomNumber", msgArr[2].trim());
                sendIntent.putExtra("MyId", msgArr[3]);
                sendBroadcast(sendIntent);
            } else {

            }
        }
        //방 참가 응답
        else if (cmd.equals("13")) {
            Intent_falg = 1;
            if (msgArr[1].equals("0")) {
                join_sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                join_sendIntent.putExtra("roomNumber", msgArr[2].trim());
                join_sendIntent.putExtra("MyId", msgArr[3]);
                sendBroadcast(join_sendIntent);
                curRoomNo = Integer.parseInt(msgArr[2]);
            } else {
                sendMsg("14");
            }
        }
        //방 새로고침 응답
        else if (cmd.equals("14")) {
            sharedPreference.setSharedTest(msgArr[1]);
            if (Integer.parseInt(msgArr[1]) != 0) {
                int roomNum = Integer.parseInt(msgArr[1]);
                for (int i = 0; i < roomNum; i++) {
                    myArrayList.add(msgArr[2 * (i + 1)]);
                }
                saveArrayList(myArrayList, "roomInfo");
                myArrayList.clear();
            } else
                Log.d("4449", "방이 없음");
        } else if (cmd.equals("17")) {
            check_Participate(msgArr);
        } else if (cmd.equals("18")) {
            if (Intent_falg == 0) {
                sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                sendIntent.putExtra("IdCode", msgArr);
                sendIntent.putExtra("myID", msgArr[1].trim());  //방장의 아이디가 들어가 있음
                sendIntent.putExtra("user1", msgArr[2].trim());
                sendIntent.putExtra("user2", msgArr[3].trim());
                sendIntent.putExtra("user3", msgArr[4].trim());
                sendBroadcast(sendIntent);
            } else {
                ArrayList<String> sendID = new ArrayList<String>();
                join_sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                join_sendIntent.putExtra("IdCode", msgArr);
                for (int i = 1; i < msgArr.length; i++) {
                    if (msgArr[i].trim().equals(id))
                        myIdIndex = i;
                    sendID.add(msgArr[i].trim());
                }
                join_sendIntent.putExtra("myIdIndex", myIdIndex);
                join_sendIntent.putExtra("user0", sendID.get(0));  //방장의 아이디가 들어가 있음
                join_sendIntent.putExtra("user1", sendID.get(1));
                join_sendIntent.putExtra("user2", sendID.get(2));
                join_sendIntent.putExtra("user3", sendID.get(3));
                sendBroadcast(join_sendIntent);
            }
        } else if (cmd.equals("19")) {
            if (Intent_falg == 0) {
                sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                sendBroadcast(sendIntent);
            } else {
                join_sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                sendBroadcast(join_sendIntent);
            }
        } else if (cmd.equals("31")) {
            int current_Turn = Integer.parseInt(msgArr[1]);
            if (Intent_falg == 0) {
                sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                sendIntent.putExtra("round", msgArr[1]);
                sendIntent.putExtra("cur_Turn", Integer.parseInt(msgArr[2].trim()));
                sendBroadcast(sendIntent);
            } else {
                join_sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                join_sendIntent.putExtra("round", msgArr[1]);
                join_sendIntent.putExtra("cur_Turn", Integer.parseInt(msgArr[2].trim()));
                sendBroadcast(join_sendIntent);
            }
        } else if (cmd.equals("33")) {
            if (Intent_falg == 0) {
                sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                sendIntent.putExtra("cardType", Integer.parseInt(msgArr[1].trim()));
                sendIntent.putExtra("nextTurn", Integer.parseInt(msgArr[2].trim()));
                sendIntent.putExtra("reminder", Integer.parseInt(msgArr[3].trim()));
                sendBroadcast(sendIntent);
            } else {
                join_sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                join_sendIntent.putExtra("cardType", Integer.parseInt(msgArr[1].trim()));
                join_sendIntent.putExtra("nextTurn", Integer.parseInt(msgArr[2].trim()));
                join_sendIntent.putExtra("reminder", Integer.parseInt(msgArr[3].trim()));
                sendBroadcast( join_sendIntent);
            }
        } else if (cmd.equals("35")) {
            if (Intent_falg == 0) {
                sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                sendIntent.putExtra("fail_flag", msgArr[1].trim());
                sendIntent.putExtra("cur_Turn",msgArr[2].trim());
                sendIntent.putExtra("reminder_Card", msgArr);
                sendBroadcast(sendIntent);
            }
            else{
                join_sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                join_sendIntent.putExtra("fail_flag", msgArr[1].trim());
                join_sendIntent.putExtra("cur_Turn",msgArr[2].trim());
                join_sendIntent.putExtra("reminder_Card", msgArr);
                sendBroadcast(join_sendIntent);
            }
        } else if (cmd.equals("36")) {
            if (Intent_falg == 0) {
                sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                sendIntent.putExtra("checkState", msgArr[1].trim());
                sendBroadcast(sendIntent);
            }
            else {
                join_sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                join_sendIntent.putExtra("checkState", msgArr[1].trim());
                sendBroadcast(join_sendIntent);
            }
        } else if (cmd.equals("37")){
            if (Intent_falg == 0) {
                sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                sendIntent.putExtra("Winner",Integer.parseInt(msgArr[1]));
                sendBroadcast(sendIntent);
            }
            else{
                join_sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim()));
                join_sendIntent.putExtra("Winner",Integer.parseInt(msgArr[1]));
                sendBroadcast(join_sendIntent);
            }
        }else if (cmd.equals("38")) {
            if (Intent_falg == 0) {
                sendIntent.putExtra("option",Integer.parseInt(msgArr[0].trim()));
                sendIntent.putExtra("nextTurn",Integer.parseInt(msgArr[1].trim()));
                sendBroadcast(sendIntent);
            }
            else{
                join_sendIntent.putExtra("option",Integer.parseInt(msgArr[0].trim()));
                join_sendIntent.putExtra("nextTurn",Integer.parseInt(msgArr[1].trim()));
                sendBroadcast(join_sendIntent);
            }

        }
        else {
            Log.d("4449", "오류");
            return;
        }
    }

    public void saveArrayList(ArrayList<String> list, String key) {   //쉐어드프리퍼런스에 배열 저장
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(key, json);
        editor.apply();     // This line is IMPORTANT !!!
    }

    public void removeAllPreferences() {    //쉐어드프리퍼런스 모두 삭제
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = pref.edit();
        editor.clear();
        editor.commit();
    }

    public void check_Participate(String[] msgArr) {
        char[] array_word = new char[msgArr[1].trim().length()];  //스트링을 담을 배열
        for (int i = 0; i < array_word.length; i++) {
            array_word[i] = (msgArr[1].trim().charAt(i)); //스트링을 한글자씩 끊어 배열에 저장
        }
        if (Intent_falg == 0) {
            sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim())); //옵션 값을 인게임 액티비티로 넘겨줌
            sendIntent.putExtra("user1", 0); //1이면 user1, 2이면 user2, 3이면 user3이다.
            sendIntent.putExtra("user1Num", array_word[0]);
            sendIntent.putExtra("user1", 1); //1이면 user1, 2이면 user2, 3이면 user3이다.
            sendIntent.putExtra("user1Num", array_word[1]);
            sendIntent.putExtra("user2", 2); //1이면 user1, 2이면 user2, 3이면 user3이다.
            sendIntent.putExtra("user2Num", array_word[2]);
            sendIntent.putExtra("user3", 3); //1이면 user1, 2이면 user2, 3이면 user3이다.
            sendIntent.putExtra("user3Num", array_word[3]);
            sendBroadcast(sendIntent);
        } else {
            join_sendIntent.putExtra("option", Integer.parseInt(msgArr[0].trim())); //옵션 값을 인게임 액티비티로 넘겨줌
            char[] userArr = new char[array_word.length - 1];
            int j = 0;
            Log.d("9981", "" + userArr);
            join_sendIntent.putExtra("juser0", 0); //1이면 user1, 2이면 user2, 3이면 user3이다.
            join_sendIntent.putExtra("juser0Num", array_word[0]);
            join_sendIntent.putExtra("juser1", 1); //1이면 user1, 2이면 user2, 3이면 user3이다.
            join_sendIntent.putExtra("juser1Num", array_word[1]);
            join_sendIntent.putExtra("juser2", 2); //1이면 user1, 2이면 user2, 3이면 user3이다.
            join_sendIntent.putExtra("juser2Num", array_word[2]);
            join_sendIntent.putExtra("juser3", 3); //1이면 user1, 2이면 user2, 3이면 user3이다.
            join_sendIntent.putExtra("juser3Num", array_word[3]);
            sendBroadcast(join_sendIntent);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        sendMsg("8");
        removeAllPreferences();
        try {
            os.close();
            is.close();
            dos.close();
            dis.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        removeAllPreferences();
        try {
            os.close();
            is.close();
            dos.close();
            dis.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        sendMsg("8");
        super.onDestroy();
    }


}


