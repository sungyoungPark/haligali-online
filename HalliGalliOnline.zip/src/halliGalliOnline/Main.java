package halliGalliOnline;

public class Main {
	public static void main(String[] args) {
		ClientManager CM = new ClientManager();
	}
}
